## 项目介绍

- 2018腾讯广告大赛baseline 100行代码带你上0.73
![Image text](https://github.com/YouChouNoBB/2018-tencent-ad-competition-baseline/blob/master/pic/leadboard.jpg)

- 1.首先处理4个G的用户特征
- 2.拼接用户特征，广告特征
- 3.将单取值的离散特征使用稀疏方式one-hot
- 4.将多取值的离散特征使用稀疏方式向量化
- 5.线下测试
- 6.线上提交
